#!/bin/sh
# Common shaper library

# UCI 'shaper' section handler.
# It will verify shaper configuration sanity and then invoke
# hardware-specific functions
handle_shaper() {
    sid="$1" #queue section ID

    config_get is_enable "$sid" "enable" 1
    # no need to configure disabled queues
    if [ "${is_enable}" == "0" ] ; then
        return
    fi


    config_get ifname "$sid" "ifname"
    # if ifname is empty that is good enough to break
    if [ -z "$ifname" ] ; then
        return
    fi

    config_get rate "$sid" "rate"
    # Convert the rate from bps to kbps.
    if [ -z "${rate}" ] || [ "${rate}" -lt 1000 ] ; then
        return
    fi

    rate=$((rate / 1000))
    config_get bs "$sid" "burst_size"

    hw_shaper_set "$ifname" add "$rate" "$bs"
}

# Configure shaper based on options saved to UCI tree 'qos.shaper'
configure_shaper() {
    # Delete existing shaper
    for intf in $(jsonfilter -i /etc/board.json -e @.network.lan.ports[*] -e @.network.lan.device -e @.network.wan.device | xargs); do
        hw_shaper_set "$intf" del
    done

    # Load UCI file
    config_load qos
    # Processing shaper section(s)
    config_foreach handle_shaper shaper
}
