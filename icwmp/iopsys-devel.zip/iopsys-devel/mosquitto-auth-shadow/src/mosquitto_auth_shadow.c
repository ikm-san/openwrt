/*
 * Copyright (c) 2022 Genexis B.V.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Erik Karlsson - initial implementation
 */

#define _GNU_SOURCE
#include <string.h>
#include <shadow.h>
#include <crypt.h>
#include <mosquitto.h>
#include <mosquitto_broker.h>
#include <mosquitto_plugin.h>

static int basic_auth_callback(int event, void *event_data, void *userdata)
{
	struct mosquitto_evt_basic_auth *ed = event_data;
	struct spwd spbuf, *sp = NULL;
	char buf[256];
	struct crypt_data data;
	char *hash;

	/* Let other plugins or broker decide about anonymous login */
	if (ed->username == NULL)
		return MOSQ_ERR_PLUGIN_DEFER;

	getspnam_r(ed->username, &spbuf, buf, sizeof(buf), &sp);

	if (sp == NULL || sp->sp_pwdp == NULL)
		return MOSQ_ERR_AUTH;

	/* Empty string as hash means password is not required */
	if (sp->sp_pwdp[0] == 0)
		return MOSQ_ERR_SUCCESS;

	if (ed->password == NULL)
		return MOSQ_ERR_AUTH;

	memset(&data, 0, sizeof(data));
	hash = crypt_r(ed->password, sp->sp_pwdp, &data);

	if (hash == NULL)
		return MOSQ_ERR_AUTH;

	if (strcmp(hash, sp->sp_pwdp) == 0)
		return MOSQ_ERR_SUCCESS;

	return MOSQ_ERR_AUTH;
}

int mosquitto_plugin_version(int supported_version_count,
			     const int *supported_versions)
{
	return 5;
}

int mosquitto_plugin_init(mosquitto_plugin_id_t *identifier,
			  void **user_data,
			  struct mosquitto_opt *opts, int opt_count)
{
	*user_data = identifier;

	return mosquitto_callback_register(identifier, MOSQ_EVT_BASIC_AUTH,
					   basic_auth_callback, NULL, NULL);
}

int mosquitto_plugin_cleanup(void *user_data,
			     struct mosquitto_opt *opts, int opt_count)
{
	mosquitto_plugin_id_t *identifier = user_data;

	return mosquitto_callback_unregister(identifier, MOSQ_EVT_BASIC_AUTH,
					     basic_auth_callback, NULL);
}
