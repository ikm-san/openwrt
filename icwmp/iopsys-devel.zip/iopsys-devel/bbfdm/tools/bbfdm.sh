#!/bin/bash

BBFDM_BASE_DM_PATH="usr/share/bbfdm"
BBFDM_INPUT_PATH="etc/bbfdm/micro_services"
INPUT_TEMPLATE='{"daemon":{"enable":"1","service_name":"template","config":{"loglevel":"1"}}}'
OUT_NAME=""

MICRO_SERVICE=0
SCRIPT=0
DIAG=0
PLUGIN=0
DEST=""
TOOLS="$( cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
SRC=""

while getopts ":mpsdu:" opt; do
	case ${opt} in
	  m)
	  	MICRO_SERVICE=1
		;;
	  p)
	  	PLUGIN=1
		;;
	  s)
	  	SCRIPT=1
		;;
	  d)
	  	DIAG=1
		;;
	  u)
	  	OUT_NAME="${OPTARG}"
		;;
	  ?)
	  	echo "Invalid option: ${OPTARG}"
		exit 1
		;;
	esac
done
shift $((OPTIND-1))

SRC="${1}"
shift
DEST="${1}"
shift
DATA="${1}"

install_bin() {
	if ! install -m0755 ${1} ${2}; then
		echo "Failed to install bin ${1} => ${2}"
		exit 1
	fi
}

install_dir() {
	if ! install -d -m0755 ${1}; then
		echo "Failed to create directory ${1}"
		exit 1
	fi
}

install_data() {
	if ! install -m0644 ${1} ${2}; then
		echo "Failed to install ${1} => ${2}"
		exit 1
	fi
}

# Installing datamodel
bbfdm_install_dm()
{
	local src dest minfile

	src="$1"
	dest="$2"
	minfile=""

	if [ -z ${src} ] || [ -z "${dest}" ] || [ -z "${TOOLS}" ]; then
		echo "Invalid input option for install dm $@"
		exit 1
	fi

	if [ "${src##*.}" = "json" ]; then
		echo "Compacting BBFDM JSON file"
		minfile=$(mktemp)
		jq -c 'del(..|.description?)' ${src} > ${minfile}

		src=${minfile}
		if dpkg -s python3-jsonschema >/dev/null 2>&1; then
			echo "Verifying bbfdm Datamodel JSON file"
			if ! ${TOOLS}/validate_plugins.py ${src}; then
				echo "Validation of the plugin failed ${src}"
				exit 1
			fi
		else
			echo "## Install python3-jsonschema to verify datamodel plugins"
		fi
	fi

	install_bin ${src} ${dest}

	if [ -f "${minfile}" ]; then
		rm ${minfile}
	fi
}

bbfdm_generate_input()
{
	local dest ser

	dest_dir=${1}
	ser=${2}
	dest=${dest_dir}/${ser}.json

	if [ -n "${OUT_NAME}" ]; then
		echo ${INPUT_TEMPLATE} | jq --arg service "${ser}" --arg OUT "${OUT_NAME}" '.daemon |= (.service_name = $service |.output.name = $OUT)' > ${dest}
	else
		echo ${INPUT_TEMPLATE} | jq --arg service "${ser}" '.daemon.service_name = $service' > ${dest}
	fi

	chmod 466 ${dest}
}

if [ -z "$SRC" ] || [ -z "${DEST}" ] ; then
	echo "# BBFDM Null value in src[${SRC}], dest[${DEST}]"
	exit 1
fi

if [ "${SCRIPT}" -eq "1" ]; then
	if [ "${DIAG}" -eq "1" ]; then
		install_dir ${DEST}/${BBFDM_BASE_DM_PATH}/scripts/bbf_diag
		install_bin ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/scripts/bbf_diag/
	else
		install_dir ${DEST}/${BBFDM_BASE_DM_PATH}/scripts
		install_bin ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/scripts/
	fi
	exit 0
fi

if [ "${MICRO_SERVICE}" -eq "1" ]; then
	if [ -z "${DATA}" ]; then
		echo "# service_name[${DATA}] not provided"
		exit 1
	fi

	if [ "${PLUGIN}" -ne "1" ]; then
		extn="$(basename ${SRC})"
		install_dir ${DEST}/${BBFDM_BASE_DM_PATH}/micro_services
		bbfdm_install_dm ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/micro_services/${DATA}.${extn##*.}

		# main micro-service datamodel plugin, create an input file as well
		install_dir ${DEST}/${BBFDM_INPUT_PATH}
		bbfdm_generate_input ${DEST}/${BBFDM_INPUT_PATH}/ ${DATA}
	else
		install_dir ${DEST}/${BBFDM_BASE_DM_PATH}/micro_services/${DATA}
		bbfdm_install_dm ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/micro_services/${DATA}/$(basename ${SRC})
	fi
else
	if [ "${PLUGIN}" -eq "1" ]; then
		priority="${DATA:-0}"
		install_dir ${DEST}/${BBFDM_BASE_DM_PATH}/plugins
		if [ "${priority}" -gt "0" ]; then
			# install with priority if defined
			bbfdm_install_dm ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/plugins/${priority}_$(basename ${SRC})
		else
			bbfdm_install_dm ${SRC} ${DEST}/${BBFDM_BASE_DM_PATH}/plugins/$(basename ${SRC})
		fi
	fi
fi

