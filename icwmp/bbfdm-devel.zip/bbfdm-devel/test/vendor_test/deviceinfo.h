#ifndef __TEST_DEVICEINFO_H
#define __TEST_DEVICEINFO_H

#include "libbbfdm-api/dmcommon.h"

extern DMOBJ tTEST_DeviceInfoObj[];
extern DMLEAF tTEST_DeviceInfoParams[];

#endif //__TEST_DEVICEINFO_H
