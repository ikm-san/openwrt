#!/bin/sh
# Install iptables rules

iptables_set_traffic_class() {
    IP_RULE="$IP_RULE -j MARK --set-xmark 0x${1}0/0xF0"
}
