# SULU-CE
SULU is a ReactJS based USP controller, for more details please check sulu [documentation](https://dev.iopsys.eu/websdk/sulu/-/blob/devel/README.md). This directory contains the recipes to build sulu for IOWRT.

There are two ways to include SULU in iowrt, by
  1. Adding a pre-build sulu distribution with all the plugins
  2. Compile sulu at the iowrt build time, which then include all the selected plugins

Align with above two ways, SULU has two variants
  1. sulu - This package usages the pre-built distribution, so it faster but only include iopsys default sulu plugins
  2. sulu-builder - This package builds the sulu along with selected plugins from sources, so user can include their sulu-plugins

# Directory structure
This directory contains iowrt sulu plugins packages along with sulu builder.

- sulu-builder - Offers sulu and sulu-builder iowrt packages
- sulu-base - Sulu core source, needed for sulu-builder
- sulu-lcm - Sulu plugin for Life Cycle Management, can be used with sulu-builder
- sulu-multi-ap - Sulu plugin for Multi-AP, can be used with sulu-builder
- sulu-parental-control - Sulu plugin for Parental control, can be used with sulu-builder
- sulu-theme-iopsys - Sulu example theme plugin, can be used with sulu-builder

# Packages
  - Select 'CONFIG_PACKAGE_sulu=y' to use pre-build sulu distribution binaries, OR
  - Select 'CONFIG_PACKAGE_sulu-builder=y' to build sulu along with customized plugins from their source code, this is the preferred way if user wants to include/exclude more/default plugins in sulu.
  - CONFIG_PACKAGE_sulu-lcm=y, handles life-cycle-management, should only be used with sulu-builder
  - CONFIG_PACKAGE_sulu-multi-ap=y, handles easy-mesh, should only be used with sulu-builder
  - CONFIG_PACKAGE_sulu-parental-control=y, Provides access-control and url-filter, should only be used with sulu-builder
  - CONFIG_PACKAGE_sulu-theme-iopsys=y, Provides an example theme, should only be used with sulu-builder

# How to select a sulu plugins
While building sulu from source, user has to select the all plugins they want to include in sulu, which can be done with 'make menuconfig', below are the list of sulu plugins available currently.
```bash
# CONFIG_PACKAGE_sulu-lcm is not set
# CONFIG_PACKAGE_sulu-multi-ap is not set
# CONFIG_PACKAGE_sulu-parental-control is not set
# CONFIG_PACKAGE_sulu-theme-iopsys is not set
```

# How to add a new sulu plugin
User can also add there own sulu plugins as package with a simple makefile as below:

```bash
include $(TOPDIR)/rules.mk
PKG_NAME:=<Name of plugin>
PKG_VERSION:=<Plugin version number>

PKG_SOURCE_PROTO:=git
PKG_SOURCE_URL:=<Plugin url>
PKG_SOURCE_VERSION:=<Plugin version hash to use>
PKG_MIRROR_HASH:=skip

include ../sulu-builder/sulu.mk

# call BuildPackage - OpenWrt buildroot signature
```

# How to add a new sulu plugin with additional install requirements
Sometimes it is required to install additional config files along with the package, to do so such sulu plugins need to have below syntax in Makefile
```bash
include $(TOPDIR)/rules.mk
PKG_NAME:=sulu-lcm
PKG_VERSION:=2.0.0

PKG_SOURCE_PROTO:=git
PKG_SOURCE_URL:=https://dev.iopsys.eu/websdk/sulu-lcm.git
PKG_SOURCE_VERSION:=b3f6028fd168e58b93ae56f616e96712849c656a
PKG_MIRROR_HASH:=skip

SULU_PLUGIN_INSTALL:=1

define Package/$(PKG_NAME)/install
	$(INSTALL_DIR) $(1)/<install_path>
	$(CP) $(PKG_BUILD_DIR)/<source_path>/lcm-store.json $(1)/<install_path>/
endef

include ../sulu-builder/sulu.mk


# call BuildPackage - OpenWrt buildroot signature
```

In the above example Makefile, if user need to install any plugin specific component, that can be added inside 'Package/$(PKG_NAME)/install' definition.

After adding the makefile, user need to specify the list of plugins in below config option, so that sulu-builder selects them and build them along with it.
```bash
CONFIG_SULU_EXTRA_PACKAGES="sulu-plugin1 sulu-plugin2 sulu-theme1"
```

# SULU PWA (Progressive Web App)
PWA applications generally used for well know secured sites, which can be installed directly from web-browser as desktop/mobile application.

> Note:
>  1. It requires well defined SSL keys for deployment of PWA for a defined site.
>  2. It should be used with sites with well defined FQDN

To enable SULU PWA application, user need to select PWA in sulu/sulu-builder config options and provide the path of the pwa key file

```bash
CONFIG_SULU_PWA_APP=y
CONFIG_SULU_PWA_KEYS_PATH="/somepath_with_pwa.{crt,key}"
```

>Note: Replacing/changing the keys might requires uninstall/install of PWA App and CTRL+Shift+R in browser to drop the cached site and load the new site with new keys.
