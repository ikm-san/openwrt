#!/bin/bash

# Function to convert parameters to lowercase
function to_lowercase {
    local params=()
    for param in "$@"; do
        params+=("$(tr '[:upper:]' '[:lower:]' <<< "$param")")
    done
    echo "${params[@]}"
}

function genconfig {
    target_script="./scripts/gen_config.py"

    # First convert all to lowercase
    args=$(to_lowercase "$@")

    # Check if an option is provided
    if [[ ${args[0]} == -* ]]; then
      # Convert options for target script
      if [[ ${args[0]}  == "-b" || ${args[0]}  == "--boards" ]]; then
        args=("--list")
      fi
    fi

    ${target_script} ${args[@]}
}

register_command "genconfig" "Generate configuration for board and customer"
