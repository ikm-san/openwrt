interfaces=$(uci show wireless | grep "ifname=" |  awk -F'[.,=]' '{print$2}')
for int in $interfaces; do
	mode=$(uci get "wireless.${int}.mode")
	if [ "$mode" = "ap" ] ; then
		ap_int=$(uci get "wireless.${int}.ifname")
		echo "Get assoc list for ${ap_int}"
		ubus call "wifi.ap.${ap_int}" assoclist
		echo "Get station info for ${ap_int}"
		ubus call "wifi.ap.${ap_int}" stations
	fi
done
