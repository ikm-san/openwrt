#!/bin/sh

. /lib/functions.sh

include /lib/network


# Parameters available in snooping configuration
igmp_s_enable=0
igmp_s_version=2
igmp_s_query_interval=125
igmp_s_q_resp_interval=100
igmp_s_last_mem_q_int=10
igmp_s_fast_leave=1
igmp_s_robustness=2
igmp_s_mode=0
igmp_s_iface=""
igmp_s_exceptions=""

mld_s_enable=0
mld_s_version=2
mld_s_robustness=2
mld_s_mode=0
mld_s_iface=""
mld_s_exceptions=""

# Global params
max_groups=25
max_msf=10
max_members=25
mldv1_unsolicited_report_interval=10
mldv2_unsolicited_report_interval=1

# Parameters available in proxy configuration
igmp_p_enable=0
igmp_p_version=2
igmp_query_interval=125
igmp_q_resp_interval=100
igmp_last_mem_q_int=10
igmp_fast_leave=1
igmp_p_robustness=2
igmp_p_mode=0
igmp_p_up_interfaces=""
igmp_p_down_interfaces=""
igmp_p_exceptions=""

mld_p_enable=0
mld_p_version=1
mld_query_interval=125
mld_q_resp_interval=100
mld_last_mem_q_int=10
mld_fast_leave=1
mld_p_robustness=2
mld_p_mode=0
mld_p_up_interfaces=""
mld_p_down_interfaces=""
mld_p_exceptions=""

read_snooping() {
	local config="$1"
	local sec_enable
	local proto

	config_get sec_enable "$config" enable 0
	config_get proto "$config" proto "igmp"

	if [ "$sec_enable" == "0" ]; then
		return
	fi

	if [ "$proto" == "igmp" ]; then
		igmp_s_enable=$sec_enable
		config_get igmp_s_version "$config" version 2
		config_get igmp_s_query_interval "$config" query_interval 125
		config_get igmp_s_q_resp_interval "$config" query_response_interval 100
		config_get igmp_s_last_mem_q_int "$config" last_member_query_interval 10
		config_get igmp_s_fast_leave "$config" fast_leave 1
		config_get igmp_s_robustness "$config" robustness 2
		config_get igmp_s_mode "$config" snooping_mode 0
		config_get igmp_s_iface "$config" interface
		config_get igmp_s_exceptions "$config" filter
		return
	fi

	if [ "$proto" == "mld" ]; then
		mld_s_enable=$sec_enable
		config_get mld_s_version "$config" version 2
		config_get mld_s_query_interval "$config" query_interval 125
		config_get mld_s_q_resp_interval "$config" query_response_interval 100
		config_get mld_s_last_mem_q_int "$config" last_member_query_interval 10
		config_get mld_s_fast_leave "$config" fast_leave 1
		config_get mld_s_robustness "$config" robustness 2
		config_get mld_s_mode "$config" snooping_mode 0
		config_get mld_s_iface "$config" interface
		config_get mld_s_exceptions "$config" filter
		return
	fi
}

read_proxy() {
	local config="$1"
	local sec_enable
	local proto

	config_get sec_enable "$config" enable 0
	config_get proto "$config" proto "igmp"

	if [ "$sec_enable" == "0" ]; then
		return
	fi

	if [ "$proto" == "igmp" ]; then
		igmp_p_enable=$sec_enable
		config_get igmp_p_version "$config" version 2
		config_get igmp_query_interval "$config" query_interval 125
		config_get igmp_q_resp_interval "$config" query_response_interval 100
		config_get igmp_last_mem_q_int "$config" last_member_query_interval 10
		config_get igmp_fast_leave "$config" fast_leave 1
		config_get igmp_p_robustness "$config" robustness 2
		config_get igmp_p_mode "$config" snooping_mode 0
		config_get igmp_p_up_interfaces "$config" upstream_interface
		config_get igmp_p_down_interfaces "$config" downstream_interface
		config_get igmp_p_exceptions "$config" filter
		return
	fi

	if [ "$proto" == "mld" ]; then
		mld_p_enable=$sec_enable
		config_get mld_p_version "$config" version 2
		config_get mld_query_interval "$config" query_interval 125
		config_get mld_q_resp_interval "$config" query_response_interval 100
		config_get mld_last_mem_q_int "$config" last_member_query_interval 10
		config_get mld_fast_leave "$config" fast_leave 1
		config_get mld_p_robustness "$config" robustness 2
		config_get mld_p_mode "$config" snooping_mode 0
		config_get mld_p_up_interfaces "$config" upstream_interface
		config_get mld_p_down_interfaces "$config" downstream_interface
		config_get mld_p_exceptions "$config" filter
		return
	fi
}

read_mcast_snooping_params() {
	config_load mcast
	config_foreach read_snooping snooping
}

read_mcast_proxy_params() {
	config_load mcast
	config_foreach read_proxy proxy
}

config_global_params() {
	local igmp_qrv
	local igmp_force_version
	local mld_qrv
	local mld_force_version

	config_load mcast
	config_get max_msf igmp max_msf 10
	config_get max_groups igmp max_membership 25
	config_get igmp_qrv igmp qrv 2
	config_get igmp_force_version igmp force_version 0

	config_get mld_qrv mld qrv 2
	config_get mldv1_unsolicited_report_interval mld mldv1_unsolicited_report_interval 10
	config_get mldv2_unsolicited_report_interval mld mldv2_unsolicited_report_interval 1
	config_get mld_force_version mld force_version 0

	if [ "$1" == "set_max_groups_and_sources" ]; then
		echo $max_groups > /proc/sys/net/ipv4/igmp_max_memberships
		echo $max_msf > /proc/sys/net/ipv4/igmp_max_msf
		echo $max_msf > /proc/sys/net/ipv6/mld_max_msf
	fi
	echo $igmp_qrv > /proc/sys/net/ipv4/igmp_qrv
	echo $igmp_force_version > /proc/sys/net/ipv4/conf/all/force_igmp_version

	echo $mld_qrv >  /proc/sys/net/ipv6/mld_qrv
	echo $mld_force_version > /proc/sys/net/ipv6/conf/all/force_mld_version
	echo $mldv1_unsolicited_report_interval > /proc/sys/net/ipv6/conf/all/mldv1_unsolicited_report_interval
	echo $mldv2_unsolicited_report_interval > /proc/sys/net/ipv6/conf/all/mldv2_unsolicited_report_interval
}
