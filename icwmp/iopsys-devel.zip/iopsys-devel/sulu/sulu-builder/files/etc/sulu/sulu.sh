#!/bin/sh

# format using "shfmt"

. /lib/functions.sh
. /usr/share/libubox/jshn.sh

RESTART_REQ=0
_RESTART_SERVICES="0"

mkdir -p /tmp/sulu/

function slog() {
	echo "$*" | logger -t sulu.init -p debug
}

function _get_agent_id() {
	local oui serial endpointid

	endpointid="$(uci_get obuspa localagent EndpointID)"
	if [ -z "${endpointid}" ]; then
		oui="$(db -q get device.deviceinfo.ManufacturerOUI)"
		serial="$(db -q get device.deviceinfo.SerialNumber)"
		echo "${oui}-${serial//+/%2B}"
	else
		endpointid="$(echo "${endpointid/::/,}" | cut -d "," -f 2)"
		endpointid="${endpointid//+/%2B}"
	fi
}

function _get_endpoint_id() {
	local oui serial endpointid

	endpointid="$(uci_get obuspa localagent EndpointID)"
	if [ -z "${endpointid}" ]; then
		oui="$(db -q get device.deviceinfo.ManufacturerOUI)"
		serial="$(db -q get device.deviceinfo.SerialNumber)"
		echo "os::${oui}-${serial//+/%2B}"
	else
		echo "${endpointid//+/%2B}"
	fi
}

function _get_sulu_user_roles() {
	roles=$(uci -q get userinterface._sulu_s.role)

	for role in ${roles}; do
		if [ -f "/etc/users/roles/$role.json" ]; then
			sulu_user_roles="${sulu_user_roles} ${role}"
		fi
	done

	if [ -n "${sulu_user_roles}" ]; then
		sulu_user_roles=$(echo -e "${sulu_user_roles// /\\n}" | sort | uniq)
	fi

	echo ${sulu_user_roles}
}

function _get_sulu_root() {
	local root

	root="$(uci -q get nginx._sulu_s.root)"
	echo "${root:-/sulu}"
}

function _get_sulu_connection_config() {
	local config

	config="$(_get_sulu_root)/presets/connection-config.json"
	echo "${config}"
}

function _get_sulu_session_mode() {
	echo "$(uci -q get sulu.global.SessionMode)"
}

function _get_usp_upstream_port() {
	local port

	port="$(uci -q get mosquitto.sulu.port)"
	echo "${port:-9009}"
}

function _get_sulu_acl_file() {
	local file

	file="$(uci -q get mosquitto.sulu.acl_file)"
	echo "${file}"
}

function _get_sulu_http_port() {
	local port listen

	listen="$(uci -q get nginx._sulu_http.listen)"
	port="$(echo $listen | grep -Eo '[0-9]+' | head -n 1)"

	echo "${port:-8080}"
}

function update_nginx_template() {
	local port

	UCI_TEMPLATE="/etc/nginx/uci.conf.template"
	port="$(_get_usp_upstream_port)"
	if ! grep -q "upstream websocket { server 127.0.0.1:${port}; }" ${UCI_TEMPLATE}; then
		sed -i "s/upstream websocket { server 127.0.0.1:[0-9]\+; }/upstream websocket { server 127.0.0.1:${var}; }/" ${UCI_TEMPLATE}
		slog "Restarting nginx"
		ubus call uci commit '{"config":"nginx"}'
	fi
}

function generate_sulu_conn_config() {
	local users SCONFIG session

	users="$(_get_sulu_user_roles)"
	session="$(_get_sulu_session_mode)"
	SCONFIG="$(_get_sulu_connection_config)"

	json_init
	json_add_string 'Current-connection' 'main'
	json_add_object 'Connections'
	{
		json_add_object 'main'
		{
			json_add_string 'toId' "$(_get_endpoint_id)"
			json_add_string 'port' "auto"
			json_add_string 'path' "/wss"

			if [ "${session}" = "Require" ]; then
				json_add_boolean 'useSession' 1
			fi

			json_add_string 'protocol' 'autoWs'
			json_add_object 'overrides'
			{
				for user in ${users}; do
					json_add_object "${user}"
					{
						json_add_string 'fromId' "self::sulu-${user}"
						json_add_string 'publishEndpoint' "/usp/$(_get_agent_id)/${user}/endpoint"
						json_add_string 'subscribeEndpoint' "/usp/$(_get_agent_id)/${user}/controller"
						json_close_object
					}
				done
				json_close_object
			}
			json_close_object
		}
		json_close_object
	}

	json_dump >${SCONFIG}
}

cleanup_sulu_usp_config() {
	local users sec stype tmp

	sec="${1}"
	stype="${2}"
	users="${3}"

	if [[ "${sec}" == "${stype}_sulu_"* ]]; then
		tmp="${sec//${stype}_sulu_/}"

		val="$(echo ${users}|grep -w -o $tmp)"
		if [ -z "$val" ]; then
			_remove_sulu_section "${sec}"
			RESTART_REQ=1
		fi
	fi
}

function _update_obuspa_config_rbac() {
	local agent users session

	agent="$(_get_agent_id)"
	users="$(_get_sulu_user_roles)"
	session="$(_get_sulu_session_mode)"

	config_foreach cleanup_sulu_usp_config controller controller "${users}"
	config_foreach cleanup_sulu_usp_config mtp mtp "${users}"
	config_foreach cleanup_sulu_usp_config mqtt mqtt "${users}"

	for user in ${users}; do
		local section

		# Add mqtt
		section="mqtt_sulu_${user}"
		if ! uci_get obuspa ${section} >/dev/null 2>&1; then
			uci_add obuspa mqtt ${section}
			uci_set obuspa ${section} BrokerAddress "127.0.0.1"
			uci_set obuspa ${section} BrokerPort "1883"
			uci_set obuspa ${section} TransportProtocol "TCP/IP"
			RESTART_REQ=1
		fi

		# Add mtp
		section="mtp_sulu_${user}"
		if ! uci_get obuspa ${section} >/dev/null 2>&1; then
			uci_add obuspa mtp ${section}
			uci_set obuspa ${section} Protocol "MQTT"
			uci_set obuspa ${section} ResponseTopicConfigured "/usp/${agent}/${user}/endpoint"
			uci_set obuspa ${section} mqtt "mqtt_sulu_$user"
			RESTART_REQ=1
		fi

		# Add controller
		section="controller_sulu_${user}"
		if ! uci_get obuspa ${section} >/dev/null 2>&1; then
			uci_add obuspa controller ${section}
			uci_set obuspa ${section} EndpointID "self::sulu-${user}"
			uci_set obuspa ${section} Protocol "MQTT"
			uci_set obuspa ${section} Topic "/usp/${agent}/${user}/controller"
			uci_set obuspa ${section} mqtt "mqtt_sulu_$user"
			uci_set obuspa ${section} assigned_role_name "$user"
			RESTART_REQ=1
		fi

		obMode="$(uci_get obuspa ${section} SessionMode)"
		if [ "${session}" != "${obMode}" ]; then
			uci_set obuspa ${section} SessionMode "${session}"
			RESTART_REQ=1
		fi
	done
}

function _remove_sulu_section() {
	local section="$1"

	if [[ "${section}" == *"_sulu_"* ]]; then
		uci_remove obuspa ${1}
		return 1
	fi
	return 0
}

function _create_acl() {
	local agentid users
	local ACL_FILE

	RESTART_REQ="0"

	ACL_FILE="$(_get_sulu_acl_file)"
	if [ -z "${ACL_FILE}" ]; then
		return 0
	fi

	if [ -f "${ACL_FILE}" ]; then
		rm -f "${ACL_FILE}"
	fi
	touch "${ACL_FILE}"

	users="$(_get_sulu_user_roles)"
	agentid="$(_get_agent_id)"
	for user in ${users}; do
		if ! grep -q "user $user" ${ACL_FILE}; then
			echo "user ${user}" >>${ACL_FILE}
			echo "topic read  /usp/${agentid}/${user}/controller/reply-to/#" >>${ACL_FILE}
			echo "topic write /usp/${agentid}/${user}/endpoint/#" >>${ACL_FILE}
			echo "topic read  /usp/${agentid}/${user}/controller/#" >>${ACL_FILE}
			echo "" >>${ACL_FILE}
			RESTART_REQ="1"
		fi
	done

	if [ "${RESTART_REQ}" -gt "0" ]; then
		slog "Restarting mosquitto..."
		ubus call uci commit '{"config":"mosquitto"}'
	fi
}

function update_obuspa_config() {

	RESTART_REQ=0
	uci_load obuspa
	_update_obuspa_config_rbac
	uci_commit obuspa

	if [ "${_RESTART_SERVICES}" -eq "1" -a "${RESTART_REQ}" -gt "0" ]; then
		slog "Restarting obuspa..."
		ubus call uci commit '{"config":"obuspa"}'
	fi
}

function configure_sulu() {
	update_obuspa_config
	_create_acl
	generate_sulu_conn_config
}

while getopts ":r" opt; do
	case ${opt} in
	r)
		_RESTART_SERVICES="1"
		;;
	*)
		slog "Invalid option: ${OPTARG}"
		exit 1
		;;
	esac
done

configure_sulu
