for radio_if in $(ubus list 'wifi.radio.*'); do
	ubus call "${radio_if}" scan
	sleep 2
	ubus call "${radio_if}" scanresults
done
