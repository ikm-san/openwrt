#!/bin/sh

configure_equipment_id() {
	local eqid="$(uci -q get xpon.ani.equipment_id)"

	set_equipment_id "${eqid}"
}

configure_loid_authentication() {
	local loid="$(uci -q get xpon.ani.loid)"
	local loid_pwd="$(uci -q get xpon.ani.loid_password)"

	set_loid_authentication "${loid}" "${loid_pwd}"
}

configure_onu_version() {
	local onu_version="$(uci -q get xpon.ani.onu_version)"

	set_onu_version "${onu_version}"
}
