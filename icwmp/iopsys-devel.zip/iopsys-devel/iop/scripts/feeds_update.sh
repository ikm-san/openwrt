#!/bin/bash

function feeds_update {

	# always return true
	exit 0
}

register_command "feeds_update" "Compatibility function only"
