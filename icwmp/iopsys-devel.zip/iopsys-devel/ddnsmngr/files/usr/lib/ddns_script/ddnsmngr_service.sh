#! /bin/sh

RUNDIR="/var/run/ddnsmngr"
LOGDIR="/var/log/ddnsmngr"
PROG="/usr/lib/ddnsmngr/ddnsmngr_updater.sh"
CONFIGFILE="/var/run/ddnsmngr/ddnsmngr.json"
CLIENT_INTFS=""

. /usr/share/libubox/jshn.sh

log() {
	echo "$*"|logger -t ddnsmngr.init -p debug
}

validate_host_section() {
	uci_validate_section ddnsmngr host "${1}" \
		'enabled:bool:0' \
		'lookup_host:string' \
		'dm_parent:string'
}

validate_client_section() {
	uci_validate_section ddnsmngr client "${1}" \
		'enabled:bool:0' \
		'service_name:string' \
		'interface:string' \
		'ip_network:string' \
		'username:string' \
		'password:string' \
		'use_https:bool:0' \
		'force_dnstcp:bool:0' \
		'use_ipv6:bool:0' \
		'force_ipversion:bool:0'
}

add_object() {
	local enabled lookup_host dm_parent use_ipv6 force_ipversion proc_info_file
	local service_name interface ip_network username password use_https force_dnstcp

	validate_host_section "${1}" || {
		log "Validation of host section failed"
		return 0
	}

	if [ "${enabled}" -ne 1 ] || [ -z "${dm_parent}" ]; then
		return 0
	fi

	validate_client_section "${dm_parent}" || {
		log "Validation of client section failed"
		return 0 
	}

	if [ "${enabled}" -ne 1 ]; then
		return 0
	fi

	service_name=$(uci -q get ddnsmngr.${dm_parent}.service_name)
	if [ -z "${service_name}" ]; then
		return 0
	fi

	service_section=$(uci -q show ddnsmngr | grep "service=\'${service_name}\'" | cut -d'.' -f 2 | head -1)
	if [ -z "${service_section}" ]; then
		return 0
	fi

	service_enabled=$(uci -q get ddnsmngr.${service_section}.enabled)
	if [ "${service_enabled}" -ne 1 ]; then
		return 0
	fi

	json_add_object
	json_add_string "interface" "${interface}"
	json_add_string "service_name" "${service_name}"
	json_add_string "username" "${username}"
	json_add_string "password" "${password}"
	json_add_string "lookup_host" "${lookup_host}"
	json_add_string "ip_network" "${ip_network}"
	json_add_string "proc_info_file" "${1}"
	json_add_string "use_ipv6" "${use_ipv6}"
	json_add_string "force_ipversion" "${force_ipversion}"
	json_add_string "use_https" "${use_https}"
	json_add_string "force_dnstcp" "${force_dnstcp}"
	json_close_object

	if [ -z "${interface}" ]; then
		if [ "${use_ipv6}" -eq 0 ]; then
			interface="wan"
		else
			interface="wan6"
		fi
	fi

	for intf in $CLIENT_INTFS; do
		if [ "${intf}" == "${interface}" ]; then
			return 0
		fi
	done

	CLIENT_INTFS="${CLIENT_INTFS} ${interface}"
}

start_ddnsmngr_service() {
	run_dir=$(uci -q get ddnsmngr.global.ddns_rundir)
	log_dir=$(uci -q get ddnsmngr.global.ddns_logdir)

	if [ -n "${run_dir}" ]; then
		RUNDIR="${run_dir}"
	fi

	if [ -n "${log_dir}" ]; then
		LOGDIR="${log_dir}"
	fi

	mkdir -p "${RUNDIR}"
	mkdir -p "${LOGDIR}"

	conf_file=$(uci -q get ddnsmngr.global.configfile)
	if [ -n "${conf_file}" ]; then
		CONFIGFILE="${conf_file}"
	fi

	touch "${CONFIGFILE}"

	if [ ! -f "${CONFIGFILE}" ]; then
		log "Can not create ${CONFIGFILE}, exit"
		exit 0
	fi

	json_init
	json_add_array "services"

	config_load ddnsmngr
	config_foreach add_object host

	json_close_array
	json_dump > "${CONFIGFILE}"

	procd_open_instance ddnsmngr
	procd_set_param command "$PROG"
	procd_append_param command -c "${CONFIGFILE}"
	procd_append_param command -- start
	procd_close_instance
}

stop_ddnsmngr_service() {
	conf_file=$(uci -q get ddnsmngr.global.configfile)
	if [ -n "${conf_file}" ]; then
		CONFIGFILE="${conf_file}"
	fi

	if [ ! -f "${CONFIGFILE}" ]; then
		log "${CONFIGFILE} not found, can't stop services if running any"
	fi

	"$PROG" -c "${CONFIGFILE}" -- stop
	return 0
}

add_ddnsmngr_triggers() {
	procd_open_trigger
	for intf in $CLIENT_INTFS; do
		# No need to handle other ifevents like ifupdate etc
		procd_add_interface_trigger "interface.*.up" $intf /etc/init.d/ddnsmngr restart
		procd_add_interface_trigger "interface.*.down" $intf /etc/init.d/ddnsmngr restart
	done
	procd_close_trigger
}
