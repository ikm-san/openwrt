#!/bin/sh

. /lib/functions.sh

CONFIG="sshd"
KEY_FILE="/root/.ssh/authorized_keys"

get_pid_file()
{
	local ServerName="$1"

	# this is they instances are named in sshd init file
	echo "/var/run/$CONFIG.$ServerName.pid"
}

get_session_pids()
{
	echo "$(ps -w | grep sshd | grep pts | awk '{print $1}')"
}
