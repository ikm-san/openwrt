#!/bin/sh

. /lib/functions.sh

KEY_FILE="/etc/dropbear/authorized_keys"
CONFIG="dropbear"

get_pid_file()
{
	local ServerName="$1"

	# this is the way instances are named in dropbear init file
	echo "/var/run/$CONFIG.$ServerName.pid"
}

get_session_pids()
{
	local PidFile="$1"

	echo "$(ps -w | grep $PidFile | grep -v grep | awk '{print $1}')"
}
