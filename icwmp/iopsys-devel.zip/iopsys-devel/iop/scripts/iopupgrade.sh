# this is a developer helper script to install firmware on a remote host with SSH

function upd_usage {
	echo "usage: $0 ssh_upgrade [-t <host>] [-f <file>] [opts] "
	echo ""
	echo "   Default host is 192.168.1.1"
	echo "   Default firmware file is the latest one (last.{itb,pkgtb})"
	echo "   Default is to not keep configuration"
	echo "opts:"
	echo ""
	echo "	-i	Interactive use, allows to select firmware file"
	echo "	-n	Do not do the final reboot of the target board"
	echo "	-c	Keep configuration"
	echo "	-x	Force install even if firmware is not for this board"
	echo "	-b	Force install of bootloader regardless of version installed"
}

function set_config_string {
	eval $(grep $1 .config)
}

function upd_ask_ok {
	echo "Will continue with the following settings:"
	echo "-----------------------------------------"
	printf "%20s: %s\n" "Firmware file" "$upd_fw_base"
	printf "%20s: %s\n" "Host IP" "$upd_host"
	printf "%20s: " "Reboot"
	if [ "$upd_noreboot" == "0" ]; then printf "Yes\n"; else printf "No\n"; fi
	printf "%20s: " "Keep config"
	if [ "$upd_keepconf" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi
	printf "%20s: " "Force bootloader"
	if [ "$upd_forceboot" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi
	printf "%20s: " "Force image upgrade"
	if [ "$upd_forceimage" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi
	echo "-----------------------------------------"

	echo -n "Continue? [Y/n/q]:"
	read answer

	case $answer in
	n | N)
		return 1
		;;
	q | Q)
		exit 1
		;;
	y | Y | *)
		return 0
		;;
	esac
}

function upd_select_file {
	dialog --keep-tite --title "To select a file, use TAB/ARROW to highlight then press SPACEBAR -> RETURN" \
		--fselect "${upd_fw:-bin/targets/$CONFIG_TARGET_BOARD/$CONFIG_TARGET_SUBTARGET/}" \
		$((lines - 10)) $((cols - 5)) \
		2>$tempfile

	new_file=$(cat $tempfile)
	if [ -n "$new_file" ]; then
		upd_fw="$new_file"
		upd_fw_base=$(basename $upd_fw)
	fi
}

function upd_select_target {
	dialog --keep-tite --title "Input the hostname/IP of the target board" \
		--inputbox "Name/IP" \
		$((lines - 10)) $((cols - 5)) \
		"$upd_host" \
		2>$tempfile

	new_file=$(cat $tempfile)
	if [ -n "$new_file" ]; then
		upd_host="$new_file"
	fi
}

function upd_select_reboot {
	dialog --keep-tite --radiolist "Should the board reboot after download finished" \
		$((lines - 5)) $((cols - 5)) $((lines - 5 - 5)) \
		"Reboot" "Restart board after done" $(if [ "$upd_noreboot" == "0" ]; then echo "ON"; else echo "OFF"; fi) \
		"No reboot" "Continue running old system" $(if [ "$upd_noreboot" == "1" ]; then echo "ON"; else echo "OFF"; fi) \
		2>$tempfile

	res=$(cat $tempfile)
	case $res in
	"No reboot")
		upd_noreboot=1
		;;
	"Reboot")
		upd_noreboot=0
		;;
	esac
}

function upd_select_config {
	dialog --keep-tite --radiolist "Should the configuration be kept" \
		$((lines - 5)) $((cols - 5)) $((lines - 5 - 5)) \
		"Keep" "Keep the config from old system" $(if [ "$upd_keepconf" == "1" ]; then echo "ON"; else echo "OFF"; fi) \
		"Default" "Use default config for new system" $(if [ "$upd_keepconf" == "0" ]; then echo "ON"; else echo "OFF"; fi) \
		2>$tempfile

	res=$(cat $tempfile)
	case $res in
	"Keep")
		upd_keepconf=1
		;;
	"Default")
		upd_keepconf=0
		;;
	esac
}

function upd_select_forceboot {
	dialog --keep-tite --radiolist "Should the boot loader be updated regardless of the version installed" \
		$((lines - 5)) $((cols - 5)) $((lines - 5 - 5)) \
		"Force" "Always update boot loader" $(if [ "$upd_forceboot" == "1" ]; then echo "ON"; else echo "OFF"; fi) \
		"Version check" "Only upgrade if version is newer" $(if [ "$upd_forceboot" == "0" ]; then echo "ON"; else echo "OFF"; fi) \
		2>$tempfile

	res=$(cat $tempfile)
	case $res in
	"Force")
		upd_forceboot=1
		;;
	"Version check")
		upd_forceboot=0
		;;
	esac
}

function upd_select_forceimage {
	dialog --keep-tite --radiolist "Should the image be stored in flash even if sanity checks would reject it" \
		$((lines - 5)) $((cols - 5)) $((lines - 5 - 5)) \
		"Force" "Disable sanity check and force use of image (dangerous)" $(if [ "$upd_forceimage" == "1" ]; then echo "ON"; else echo "OFF"; fi) \
		"Only compatible" "Normal checks apply" $(if [ "$upd_forceimage" == "0" ]; then echo "ON"; else echo "OFF"; fi) \
		2>$tempfile

	res=$(cat $tempfile)
	case $res in
	"Force")
		upd_forceimage=1
		;;
	"Only compatible")
		upd_forceimage=0
		;;
	esac
}

function upd_select {
	dialog --keep-tite --ok-label "Select" --cancel-label "Done" --menu "Select item to change" \
		$((lines - 5)) $((cols - 5)) $((lines - 5 - 5)) \
		"Firmware file" "$upd_fw_base" \
		"Host IP" "$upd_host" \
		"Reboot" $(if [ "$upd_noreboot" == "0" ]; then printf "Yes\n"; else printf "No\n"; fi) \
		"Keep config" $(if [ "$upd_keepconf" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi) \
		"Force bootloader" $(if [ "$upd_forceboot" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi) \
		"Force image upgrade" $(if [ "$upd_forceimage" == "1" ]; then printf "Yes\n"; else printf "No\n"; fi) \
		2>$tempfile

	case $(cat $tempfile) in
	"Firmware file")
		upd_select_file
		;;
	"Host IP")
		upd_select_target
		;;
	"Reboot")
		upd_select_reboot
		;;
	"Keep config")
		upd_select_config
		;;
	"Force bootloader")
		upd_select_forceboot
		;;
	"Force image upgrade")
		upd_select_forceimage
		;;
	*)
		return
		;;
	esac
	upd_select
}
function upd_select_start {
	lines=$(tput lines)
	cols=$(tput cols)
	tempfile="$(mktemp)"
	trap "rm -f $tempfile" 0 1 2 5 15
	upd_select

}

function ssh_upgrade {
	upd_noreboot=0
	upd_forceboot=0
	upd_keepconf=0
	upd_forceimage=0
	upd_fw_base=""
	upd_fw=""
	upd_host="192.168.1.1"
	do_dialog=0

	while getopts "f:hnxt:icb" opt; do
		case $opt in
		n)
			upd_noreboot=1
			;;
		x)
			upd_forceimage=1
			;;
		b)
			upd_forceboot=1
			;;
		c)
			upd_keepconf=1
			;;
		v)
			verbose=$OPTARG
			;;
		f)
			upd_fw=$OPTARG
			;;
		t)
			upd_host=$OPTARG
			;;
		i)
			do_dialog=1
			;;
		h)
			upd_usage
			exit 1
			;;
		\?)
			echo "Invalid option: -$OPTARG" >&2
			exit 1
			;;
		esac
	done

	if [ -z "$upd_fw" ]; then
		set_config_string CONFIG_TARGET_BOARD
		set_config_string CONFIG_TARGET_SUBTARGET
		upd_fw="$(realpath -q --canonicalize-existing --relative-to=. "bin/targets/$CONFIG_TARGET_BOARD/$CONFIG_TARGET_SUBTARGET/"last.{pkgtb,itb})"
		if [ -z "$upd_fw" ] && [ $do_dialog -eq 0 ]; then
			echo "Could not find image. Check that last.{itb,pkgtb} exists or specify an image using -f <image> or -i (interactive)." >&2
			return 1
		fi
	fi
	upd_fw_base="$(basename "$upd_fw")"

	[ $do_dialog -eq 1 ] && upd_select_start

	if ! upd_ask_ok; then
		upd_select_start
		if ! upd_ask_ok; then
			exit 1
		fi
	fi

	if [ ! -f $upd_fw ]; then
		echo "Firmware file $firmware does not exist."
		exit 1
	fi

	extra_args=""
	[ $upd_noreboot -eq 1 ] && extra_args="$extra_args --no-reboot"
	[ $upd_forceimage -eq 1 ] && extra_args="$extra_args --force"
	[ $upd_keepconf -eq 0 ] && extra_args="$extra_args -n"
	[ $upd_forceboot -eq 1 ] && extra_args="$extra_args --force-loader-upgrade"

	pv "$upd_fw" |
		ssh \
			-o ConnectTimeout=60 \
			-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
			root@"$upd_host" \
			sh -c "cat > '/tmp/$upd_fw_base' && (set -x && sysupgrade -v $extra_args /tmp/$upd_fw_base)" ||
		echo "Sysupgrade failed" >&2 && return 1
}

register_command "ssh_upgrade" "-t <host> -f <file> [opts]  Install firmware on remote host with SSH"
