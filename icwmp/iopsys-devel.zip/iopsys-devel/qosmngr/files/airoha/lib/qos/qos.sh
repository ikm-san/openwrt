#!/bin/sh
# The entrypoint for the QoS setup library

. /lib/functions.sh
include /lib/ethernet

. /lib/qos/iptables.sh
. /lib/qos/chains.ebtables.sh
. /lib/qos/chains.iptables.sh
. /lib/qos/ebtables.sh
. /lib/qos/ip_rule.sh
. /lib/qos/classify.sh
. /lib/qos/policer.sh
. /lib/qos/queue.sh
. /lib/qos/shaper.sh
. /lib/qos/airoha.sh

# marking value be decimal for linux target as it uses set-mark whereas other
# targets uses set-xmark, hence this function can't make it common
ip_rule_get_converted_tos() {
	con_tos=$(printf %x $1)
	echo $con_tos
}

configure_qos() {
    # queue configuration is being done after shaper configuration,
    # If port shapingrate configuration on DISC device is called after queue configuration then
    # driver overwrites the queue shaping rate with default value of port shaping rate.
    pre_configure_queue
    setup_qos
    configure_shaper
    configure_queue
    configure_policer
    configure_classify
    if [ -f "/tmp/qos/classify.ebtables" ]; then
	    sh /tmp/qos/classify.ebtables
    fi
}

reload_qos() {
    local service_name="$1"

    hw_init_all
    case "${service_name}" in
        shaper)
            configure_shaper
            ;;
        queue)
            pre_configure_queue
            configure_queue
            ;;
        classify)
            configure_classify
            if [ -f "/tmp/qos/classify.ebtables" ]; then
                sh /tmp/qos/classify.ebtables
            fi
            ;;
        policer)
            configure_policer
            ;;
        "")
            configure_qos
            ;;
    esac
    hw_commit_all
}

reload_qos_service() {
	reload_qos
}
