#!/bin/sh

. /lib/functions.sh

set_serial_number() {
	local vendor_id="$1"
	local vssn="$2"

	vendor_id="$(echo "${vendor_id}" | hexdump -e '4/1 "%02X" "\n"')"
	vendor_id="${vendor_id:0:8}"

	bs /b/c gpon onu_sn={vendor_id=$vendor_id,vendor_specific=$vssn}
}

set_equipment_id() {
	local equipment_id="$1"
	[ -z "$equipment_id" ] && return

	json_add_string "equipment_id" "$equipment_id"
}

set_loid_authentication() {
	local loid="$1"
	local loid_password="$2"

	[ -z "$loid" ] && return

	json_add_string "loid" "$loid"
	json_add_string "loid_password" "$loid_password"
}

set_onu_version() {
	local onu_version="$1"
	[ -z "${onu_version}" ] && return

	json_add_string "onu_version" "${onu_version}"
}

apply_xpon_uci_config() {
	local sn

	json_init
	json_add_object 'ani'
	sn="$(uci -q get xpon.ani.serial_number)"
	json_add_string "serial_number" "$sn"
	configure_loid_authentication
	configure_equipment_id
	configure_onu_version
	json_close_object
	json_dump > /tmp/xpon.json
}

init_xpon() {
	procd_open_instance pon_daemon
	procd_set_param command omcid start -n
	procd_set_param respawn
	procd_close_instance
}

deinit_xpon() {
	# stopping omcid does not bring down the pon link, which should happen
	# if ANI is disabled or stopped (go to O1)
	gponctl stop
}
